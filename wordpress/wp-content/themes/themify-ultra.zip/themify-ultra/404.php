<?php
/**
 * Intermediate template for 404 error pages. Calls page.php template.
 * @package themify
 * @since 1.0.0
 */
?>
<?php get_template_part( 'page', '404' ); ?>