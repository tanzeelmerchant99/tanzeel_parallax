<?php
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly
/**
 * Template Page Break
 *
 * Access original fields: $args['mod_settings']
 * @author Themify
 */
?>
<!-- module page break -->
<div class="tb-page-break-pagination"></div>
<!-- /module page break -->
